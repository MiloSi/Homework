package com.si.hw2_by_c;


import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.EditText;
import android.text.TextWatcher;
import android.text.Editable;
import android.view.View;
import android.view.View.OnFocusChangeListener;
import android.widget.Toast;

/*
어플을 키면 가장 먼저 볼 액티비티임.
사실 가장 먼저 뜨는 것은 메뉴엑티비티지만
메뉴엑티비티가 oncreate 상태가 되면 바로 이 액티비티가 활성화 하도록 설정됨.

여기서 하는 건 암호를 체크하는 것.
 */
public class PwLayoutActivity extends AppCompatActivity {


    Intent pwIntent; //인텐트를 주거니 받거니 하기 위해 설정.
    SharedPreferences pw; //암호를 받기 위해서 설정.

    EditText txt[] = new EditText[4]; // 암호를 입력하기 위해 설정.

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        pwIntent = getIntent();
        pw = getSharedPreferences("PW", MODE_PRIVATE); // 암호를 받을 수 있도록 설정함.

        super.onCreate(savedInstanceState);
        setContentView(R.layout.pw_layout);

        //위의 4개의 에디트 텍스트를 xml과 연동 할 수 있도록 설정.

        txt[0] = (EditText) findViewById(R.id.one);
        txt[1] = (EditText) findViewById(R.id.two);
        txt[2] = (EditText) findViewById(R.id.three);
        txt[3] = (EditText) findViewById(R.id.four);



        //사실 에디트 텍스트 하나 입력되면 다른 에디트에 커서가 가게 할려고
        //공부하는 과정에서 이걸 발견했는데, 그냥 포커스를 가지면 색깔이 변하게 하도록
        //하는 이벤트리스너임. 별 중요하지 않음.
        OnFocusChangeListener change = new OnFocusChangeListener() {

            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                for(int i = 0; i < 4; i++) {
                    if(v == txt[i]) {

                        if(hasFocus) { //포커스를 가지면 색깔이 변하게 함.
                            v.setBackgroundColor(Color.rgb(255,248,220));
                        }
                        else
                            v.setBackgroundColor(Color.rgb(255,255,255));
                    }
                }
            }
        };

        /*
        각 에디트 텍스트가 있는데,
        여기서 하나의 에디트 텍스트에 숫자를 입력하면 다음 에디트에 포커스로 넘어가도록 하는 리스너.
        만약 마지막 텍스트를 입력하면 지금까지 입력한 숫자가 암호와 일치하는지 설정.
        일치하면 MENU로 돌아가도록 설정
         */
        TextWatcher txtchange = new TextWatcher() {
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                for(int i  = 0; i < 4; i++) {
                    if(txt[i].getText().toString().length()>=1) { // 에디트 텍스트에 글자를 입력했다면 다른 에디트 텍스트가 포커스를 가지도록.
                        if(i != 3) {

                            txt[i].requestFocus(); //일부로 한번 더 자기에다 포커스를 둔 후 다음으로 넘어가도록 설정했는데,
                            txt[i+1].requestFocus(); // 그 이유는 이렇게 하면 화면에서 보여주는 암호화가 제대로 보여주기 때문임.
                        }
                        else { //4개의 텍스트가 완성됬으면 암호와 비교하도록 설정.

                            String Pw = "";
                            for(int j = 0; j < 4; j++) { //지금까지 입력한 글자를 한 스트링으로 합침.
                                Pw = Pw + txt[j].getText().toString();
                            }

                            if(Pw.compareTo(pw.getString("password",null))==0) { //만약 정확하면 돌아가도록 함.


                                Toast.makeText(getApplicationContext(), "Welecome", Toast.LENGTH_SHORT).show();
                                setResult(RESULT_OK, pwIntent);
                                finish();
                            }
                            else { //잘못되었다고 설정.

                                Toast.makeText(getApplicationContext(), "Wrong ", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                }
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // TODO Auto-generated method stub
              //  Log.i("beforeTextChanged", s.toString());
            }
            public void afterTextChanged(Editable s) {

            }
        };
        for (int i = 0; i < 4; i ++) { //이벤트를 받을 수 있도록 함.
            txt[i].setOnFocusChangeListener(change);
            txt[i].addTextChangedListener(txtchange);
        }
        txt[0].requestFocus();
    }


}
