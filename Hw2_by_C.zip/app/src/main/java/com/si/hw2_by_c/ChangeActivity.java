package com.si.hw2_by_c;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Created by LG on 2016-04-29.
 */
/*
여기서는 암호를 변경 할 수 있도록 해주는 activity임.
암호 4글자를 입력하고
okay 누르면 암호가 변경되는데
암호는 무조건 4글자이어야 한다.

 */

public class ChangeActivity extends AppCompatActivity{

    //버튼들과 에디트 텍스트인데 각각 확인, 취소, 암호를 보여줌.
    Button okay, cancel;
    EditText editText;

    SharedPreferences pw; //기본 암호가 들어 있는데
    Intent intent;
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.change_layout);

        intent = getIntent();  //인텐드 초기설정. 안해도 됨.


        // 자바와 레이아웃에 있는 뷰들을 연결 시켜줌.
        okay = (Button)findViewById(R.id.okay);
        cancel = (Button)findViewById(R.id.cancel);
        editText = (EditText)findViewById(R.id.changepw);



        //버튼 클릭 리스너, 입력한 텍스트를 가지고(텍스트는 4글자로 제한, 숫자) 암호를 변경 할 수 있도록 하는 거랑, 그냥 취소 하는 옵션을 가짐.
        OnClickListener onClickListener = new OnClickListener() {
            @Override
            public void onClick(View v) {
                if(v.getId() == okay.getId()) {
                    if(editText.getText().toString().length() < 4) { //4글자가 아니면 다시 하도록 초기화 시킴.
                        Toast.makeText(getApplicationContext(),"Please Input Length 4",Toast.LENGTH_SHORT).show();
                        editText.setText("");
                    }
                    else { //조건이 맞으면 암호를 변경하도록 설정.
                        pw = getSharedPreferences("PW", MODE_PRIVATE); // 저장공간 pw
                        SharedPreferences.Editor editor = pw.edit();
                        editor.putString("password",editText.getText().toString());
                        editor.commit();
                        setResult(RESULT_OK,intent);
                        finish();
                    }
                }
                else if(v.getId() == cancel.getId()) { // 취소 버튼 누르면 변경 없이 취소됨.
                    setResult(RESULT_CANCELED,intent);
                    finish();
                }
            }
        };

        //    그리고 버튼들 이벤트를 다룰 수 있도록 설정.
        okay.setOnClickListener(onClickListener);
        cancel.setOnClickListener(onClickListener);


    }
}
