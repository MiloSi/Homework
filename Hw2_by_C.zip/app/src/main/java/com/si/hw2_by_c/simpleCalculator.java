package com.si.hw2_by_c;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.view.View;
import android.widget.TextView;
import android.content.*;
import android.widget.Toast;

/**
 * Created by LG on 2016-04-28.
 */

/*

finding this program can work completely .

checking    1.  4 + 5 =  // just finding this calculator nomarly operate
            2.  4 * 5 + 3 =
            3.  4 + 5 - 6 = + 5 =
            4.  5 * 6 / 3 / 0

일단 저희 집에 있는 계산기가 작동하는 원리로 만듦.
배경은 교수님 예제를 따왔습니다.
queue 원리를 이용해서 계산기가 되도록 했습니다.


고려사항은 '=' 처리와 한 연산자 누르고 다른 연산자 눌러질 때 입니다. (위에서 +  * - 이런식으로 순서대로 누를 때, 저희 집 계산기는 -를 최종으로 인식했습니다.
 */
public class simpleCalculator extends AppCompatActivity implements OnClickListener { //OnclickListener 를 implements로 했습니다.
    Intent intent;
    Button[] NumberBt= new Button[10]; // means number (0~9) buttons
    Button [] OperBt = new Button[5];  // means +, -, X, /, = buttons
    Button ClearBt; // means reset button
    TextView result; // show result.
    Bundle bundle;

    String[] Number = {"0", "0"}; // means frist operand and scond operand //
    int Nque = 0; // 어디에 숫자가 들어갔는지 알게 해줌.

    int[] order = {4, 4}; // 연산자도 queue 형식으로 해서 첫번째거 하면 두번째 연산자가 앞으로 오도록 했습니다.
    int Oque = 0;

    double A, B; // 피연산자인데 위의 Number는 String이라서 이걸 수로 바꾼 값을 저장합니다.
    String showResult = "0";
    boolean tip = true; //계산기 숫자 버튼을 눌렀는지 확인합니다. 처음에는 0을 눌렀다는 가정으로 해서 true로 했습니다.


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.calculator_layout);

        intent = getIntent();

        // this step will link textview all buttons with andriod buttons first number buttons
        result = (TextView) findViewById(R.id.calculating);

        NumberBt[0] = (Button) findViewById(R.id.zero);
        NumberBt[1] = (Button) findViewById(R.id.one);

        NumberBt[2] = (Button) findViewById(R.id.two);
        NumberBt[3] = (Button) findViewById(R.id.three);
        NumberBt[4] = (Button) findViewById(R.id.four);
        NumberBt[5] = (Button) findViewById(R.id.five);
        NumberBt[6] = (Button) findViewById(R.id.six);
        NumberBt[7] = (Button) findViewById(R.id.seven);
        NumberBt[8] = (Button) findViewById(R.id.eight);
        NumberBt[9] = (Button) findViewById(R.id.nine);


        //last buttons
        OperBt[0] = (Button) findViewById(R.id.add);
        OperBt[1] = (Button) findViewById(R.id.sub);
        OperBt[2] = (Button) findViewById(R.id.mult);
        OperBt[3] = (Button) findViewById(R.id.div);
        OperBt[4] = (Button) findViewById(R.id.equal);
        ClearBt = (Button) findViewById(R.id.clear);

        // link all button
        for (int i = 0; i < 10; i++) {
            NumberBt[i].setOnClickListener(this);
        }
        for (int i = 0; i < 5; i++) {
            OperBt[i].setOnClickListener(this);
        }

        ClearBt.setOnClickListener(this);
    }
        @Override
        public void onClick(View v)
        {
            for(int i = 0; i < 10; i++) {
                if (v.getId() == NumberBt[i].getId()) {

                    if(showResult == "0") // when start 0 (시작이 0인데 계속 숫자를 넣으면 이상해지기 때문에  막아놨습니다.
                        showResult = "";
                    if(tip == false) { // tip mean add number. not change all number.
                        showResult = "";
                        tip = true;
                    }
                    showResult = showResult + i;
                    result.setText(showResult);
                }
            }
            for(int i = 0; i < 5; i++) {
                if (v.getId() == OperBt[i].getId()) {
                    if (i == 4) {// '=' 이거 누르면 메뉴로 돌아가게 하는데,
                        if (Oque == 0) { // 아무런 연산 없이 수 입력 후 이걸 누를 경우
                            Double a = Double.parseDouble(showResult);
                            bundle = new Bundle();
                            bundle.putDouble("result", a);
                            intent.putExtras(bundle);
                            setResult(1, intent);
                            finish();
                        }
                        else if(tip == false) { //다른 연산 누른 후 = 누르는 경우
                            bundle = new Bundle();
                            bundle.putDouble("result",Double.parseDouble(Number[0]));
                            intent.putExtras(bundle);
                            setResult(1, intent);
                            finish();
                        }
                  }

                /*
                checking +, -, *, /, and =
                 */
                    /* 여기 코드에선 이게 필요없을 것 같네요.
                  if(i == 4 && tip == false) { // 숫자를 누르지 않았는데 누른 연산자가 = 이면 맨 앞에 있는 연산자로 가게 합니다.

                        showResult = ""+ Number[0];
                        result.setText(showResult);
                        tip = false;
                        break;
                    }*/
                    if(Oque == 1 && tip == false) { // 아무 숫자를 안 넣고 그냥 operation 만 바꿀려고 할 때.
                        order[0] = i;
                        break;
                    }

                    Number[Nque] = showResult; // save first operand
                    Nque ++;

                    order[Oque] = i;
                    Oque++;

                    if (Nque == 2) { // when complete all operands.  그냥 피연산자가 다 있으면

                        calculating();
                        order[0] = order[1]; // when finish calculating, input second operation into first operation  like queue.
                        Number[0] = showResult;



                        if(order[1] == 4) { // make first operation chagneable state when inputting =
                            Oque = 0;
                            Nque = 0;
                        }
                        else {
                            Oque = 1;
                            Nque = 1;
                        }
                        result.setText(showResult);
                        tip = false;

                        break;
                    }
                    result.setText(showResult);
                    tip = false; //can change
                }
            }
            if(v.getId() == ClearBt.getId()) {
                showResult = "0";
                Number[0] = "0";
                Nque = 0;
                order[0] = 4;
                Oque = 0;
                tip = true;
                result.setText(showResult);
            }
        // link all button
        for(int i = 0; i < 10; i++) {
            NumberBt[i].setOnClickListener(this);
        }
        for(int i = 0; i < 5; i++) {
            OperBt[i].setOnClickListener(this);
        }

        ClearBt.setOnClickListener(this);

    }
    public void calculating() { // calculate using two operand and first


        A = Double.parseDouble(Number[0]); // second
        B = Double.parseDouble(Number[1]); // first

        if(order[0] == 0) { // add
            A = A + B;
            showResult = ""+A;
        }
        else if(order[0] == 1) { // sub
            A = A - B;
            showResult = ""+A;
        }
        else if(order[0] == 2) { //multi
            A = A * B;
            showResult = ""+A;
        }
        else if(order[0] == 3) { //  divide
            if(B == 0) { // 만약 0으로 나눌려고 하면 못한다고 toast 이용해서 이야기하고 다시 맨 앞의 연산자를 보여주게 합니다.
                if(order[1] == 4) { // 그런데 마지막 연산이 = 이면 더 이상 계산기 이용을 하지 않고 메뉴로 가서 잘못된 연산임을 말하게 합니다.
                    setResult(-1, intent);
                    finish();
                }
                //Toast.makeText(getApplicationContext(), "Can not Divided by 0", Toast.LENGTH_LONG).show();
                showResult = ""+A;
                return;
            }

            A = A / B;
            showResult = "" + A;

        }
        if(order[1] == 4) { //기존에서 새로 추가된 부분!!  (성공적으로 결과가 나올 때)
            bundle = new Bundle();
            bundle.putDouble("result", A);
            intent.putExtras(bundle);
            setResult(1,intent);
            finish();
        }

    }
}
