package com.si.hw2_by_c;

/**
 * Created by LG on 2016-04-16.
 */

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;


/*
여기서는 메뉴에서 선택한 리스트를 보내기 위한 엑티비티.
메뉴에서 무슨 선택을 했는지 알기 위해서 메뉴에서는 번들로 뭘 할지를 보내줌.
 */

public class PathLayoutActivity extends AppCompatActivity {

    Button bt;
    TextView textView;

    Intent path_intent; //사실 인텐트를 2개 사용 할 필요성은 못느끼지만 그래도 구분하기 위해서 2개 만듬.
    Intent order_intent; // path_intent 정보를 받는 인텐트고, order_intent는 정보를 보내기 위한 인텐트임.
    String[] descript; //텍스트 화면에 무엇을 하는지 알려주기 위해서 만든 string. 정보는 values/strings에 있다.
    int order;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.path_layout);

        path_intent = getIntent(); //인텐트 정보를 가지고 옴.

        Bundle bundle = new Bundle(); //번들을 만들어서 인텐트 안에 있는 번들 내용을 저장함.
        bundle = path_intent.getExtras();
        order =  bundle.getInt("order");

        descript = getResources().getStringArray(R.array.description); // values/strings에 있는 글들을 저장하게 함.
        bt = (Button)findViewById(R.id.button);
        textView = (TextView)findViewById(R.id.bigTxt);

        textView.setText(descript[order]); //메뉴 엑티비티에서 몇번째 리스트를 눌렀는가에 따라 보여주는 화면이 다르도록 설정.

        if(order == 0) {
            order_intent = new Intent(this, myTimeTable.class); // 내 시간표로 가도록 하는 인텐트
        }
        else if(order == 1) {
            order_intent = new Intent(this, tipCalculator.class); // 팁 계산기로 가도록 하는 인텐트
        }
        else if(order == 2) {
            order_intent = new Intent(this, simpleCalculator.class); // 계산기로 가도록 하는 인텐트
        }

        OnClickListener click = new OnClickListener() {

            public void onClick(View v) { //솔직히 계산기를 제외하고는 다른 엑티비티의 결과값은 중요하지 않음. 그래서 계산기만 별도의 requestCode로 설정함.
                if(order != 2)
                    startActivityForResult(order_intent,200);
                else
                    startActivityForResult(order_intent,201);
            }
        };

        bt.setOnClickListener(click);
    }


    /*
    pathActivity에서 시간표 계산기 팁 계산기로 간 후 뒤로가기 누르면 pathActivity 아닌
    메뉴엑티비티로 가도록 설정했음.
     */
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            if(requestCode == 201) { //이것이 계산기임.

                if (resultCode == 1) { //= 눌렀을 때 결과값이 문제 없으면 다시 저장해서 메뉴로 보내줌.

                    Bundle bundle = new Bundle();
                    bundle = data.getExtras();
                    path_intent.putExtras(bundle);

                    setResult(1, data);

                    finish();

                } else if (resultCode == -1) { //0으로 나눌 때 resultCode는 -1로 나오도록 함.
                    setResult(-1, data);
                    finish();
                }
                else { //그냥 뒤로가기 누를 때
                    setResult(0, data);
                    finish();
                }
            }
            else if(requestCode == 200) { //그 외 다른 엑티비티는 뒤로 가기 누르면 메뉴로 돌아가게 함.

                setResult(RESULT_OK, order_intent);
                finish();
            }
        } catch (
                Exception e) {
        }
    }//onActivityResult
}
