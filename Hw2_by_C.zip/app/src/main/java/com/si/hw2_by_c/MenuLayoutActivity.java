package com.si.hw2_by_c;

import android.content.Context;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.ListActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import android.content.SharedPreferences;

import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;


/*


the first activity when you operate this application.
but, you will show password activity.
because when this activity created, this activity make intent password activity.


 */

public class MenuLayoutActivity extends ListActivity {

    String[] list; // 아이템 안에 다 있어요~ 여기서 리스트 보여줌.
    SharedPreferences pw; //암호가 들어가 있는 프리퍼런스.
    double result; //결론적으로


    //암호 인텐트는 200
    //그외 인텐트는 100, 101, 102, 103임. (순서대로 시간표, 팁 계산기, 계산기, 암호변경)
    //그런데 핵심적으로 주거니 받거니 할 만한건 200과 102, 103임 그래서 이 3가지만 result로 받을 예정. 나머지는 else를 이용해서  menu로 돌아왔다고 toast로 뜨게 해줄 예정.
    static final int PWcode = 200;
    static final int CulculaterCode = 102;
    static final int ChangeCode = 103;

    static final String InitialPw = "0000"; //초기 암호 0000으로 설정했습니다.
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;


    /*
    일단 만들어지면  sharedPreferences()로 가서 암호를 설정하는데 이건 초기에만 설정하도록 했음 (using if(pw == null)
    */
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        Intent goPw = new Intent(this, PwLayoutActivity.class);
        sharedPrefernces(); //초기 암호 설정.

        super.onCreate(savedInstanceState);
        startActivityForResult(goPw, PWcode); //먼저 암호가 맞는지 확인하는 PwLayoutActivity


        // setContentView(R.layout.menu_layout); // 이거 일단 필요 없음.

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
    }

    /*
    인텐드에서 결과를 보여주는데 그 중에서 시간표와 팁 계산기는 else로 해서 그냥 돌아왔다고 표현.
     */
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            if (requestCode == PWcode) {  // PWcode는 200을 의미함.
                if (resultCode == RESULT_OK) { //암호를 제대로 입력했다면, 이제 화면에 리스트를 보여주도록 함.
                    list = getResources().getStringArray(R.array.List); // 여기에다 values 안에 있는 아이템들 집어 넣음.

                    MySimpleArrayAdapter adapter = new MySimpleArrayAdapter(this, list);
                    setListAdapter(adapter);
                } else { //암호도 제대로 입력 안하고 백 버튼 누르거나 강제로 들어갈려고 할 때 종료하도록 설정.
                    finish();
                }
            } else if (requestCode == CulculaterCode) { //CulculaterCode는 102임.
                if (resultCode == 1) { // 계산기에서 = 를 입력했고, 그 결과에 이상이 없을 경우.
                    result = data.getExtras().getDouble("result");
                    Toast.makeText(getApplicationContext(), "The Result: " + result, Toast.LENGTH_SHORT).show();
                } else if (resultCode == -1) { // 계산기에서 = 를 입력했는데, 0으로 나눈 경우.
                    Toast.makeText(getApplicationContext(), "Can't Divided by 0", Toast.LENGTH_SHORT).show();
                } else // 그냥 back버튼 누를 경우
                    Toast.makeText(getApplicationContext(), "Return Menu", Toast.LENGTH_SHORT).show();

            } else if (requestCode == ChangeCode) { //ChangeCode는 103
                if (resultCode == RESULT_OK) { //Okay버튼 눌러서 정상적으로 암호가 변경 됬을 때
                    Toast.makeText(getApplicationContext(), "Change Complete", Toast.LENGTH_SHORT).show();
                } else //변경하지 않고 그냥 back버튼 누르거나 할 때.
                    Toast.makeText(getApplicationContext(), "Change Cancel", Toast.LENGTH_SHORT).show();
            } else//다른 intent들은 그냥 이것만 보여주도록 합니다.
                Toast.makeText(getApplicationContext(), "Return Menu", Toast.LENGTH_SHORT).show();
        } catch (
                Exception e) {
        }
    }//onActivityResult

    public void onListItemClick(ListView parent, View v, int position, long id) {

        /*
        리스트는 총 4개. (위부터 시간표, 팁 계산기, 심플 계산기, 암호변경)
        그 중 시간표, 팁 계산기, 심플 계산기는 pathLayoutActivity로 가도록 설정
        pathLayoutActivity에서는 getIntent를 통해서 정보를 받아오는데(int값으로 되어있는 정보), 0이면 시간표 1이면 팁계산기 2면 계산기로 갈 수 있도록 하는 설정이다.

         */
        if (position != 3) {//3번은 패스워드 변경할 때임.
            Intent goPath = new Intent(this, PathLayoutActivity.class);
            Bundle bundle = new Bundle();
            bundle.putInt("order", position);
            goPath.putExtras(bundle);
            startActivityForResult(goPath, (position + 100));
        } else {
            Intent goChagne = new Intent(this, ChangeActivity.class);
            startActivityForResult(goChagne, (position + 100));
        }

        Toast.makeText(this,
                "You have selected " + list[position],
                Toast.LENGTH_SHORT).show();
    }

    public void sharedPrefernces() {
        pw = getSharedPreferences("PW", MODE_PRIVATE); // 저장공간 pw

        if (pw == null) {
            SharedPreferences.Editor edit = pw.edit(); // 수정할 수 있도록 해줌.
            edit.putString("password", InitialPw);
            edit.commit();
        }
    }
 //여기서 list에다 icon을 넣도록 함.
    //학교 ppt내용을 조금 수정함.
    public class MySimpleArrayAdapter extends ArrayAdapter<String> {
        private final Context context;
        private final String[] values;

        public MySimpleArrayAdapter(Context context, String[] values) {
            super(context, R.layout.list_layout, values);
            this.context = context;
            this.values = values;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View rowView = inflater.inflate(R.layout.list_layout, parent, false);
            TextView textView = (TextView) rowView.findViewById(R.id.label);
            ImageView imageView = (ImageView) rowView.findViewById(R.id.icon);
            textView.setText(values[position]);

            String s = values[position];

            //모든 그림들은 구글에서 퍼옴.
            if (s.startsWith("My Timetable"))
                imageView.setImageResource(R.drawable.time);
            if (s.startsWith("My Tip Calculator"))
                imageView.setImageResource(R.drawable.tip);
            if (s.startsWith("My Simple Calculator"))
                imageView.setImageResource(R.drawable.calculate);
            if (s.startsWith("My Change Password"))
                imageView.setImageResource(R.drawable.change);

            return rowView;
        }
    }
}

